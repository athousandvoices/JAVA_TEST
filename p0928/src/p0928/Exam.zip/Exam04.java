package p0928;

import java.util.Scanner;

public class Exam04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s1=new Scanner(System.in);
		int num1, i, j;
		System.out.print("정숫값:");
		num1=s1.nextInt();
		for (i=1; i<=num1; i++){
			j=i*i;
			if(i==num1){
			System.out.println(num1+"의 제곱은"+j+"입니다.");
			}else{
				System.out.println(i+"의 제곱은"+j+"입니다.");
			}
		}
	}

}
