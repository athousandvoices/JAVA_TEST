package p0928;

public class Exam11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1; i<6; i++){
			for(int j=0; j<i; j++){
				System.out.printf("*");
			}
			System.out.println();
		}
	}

}
