package p0928;

public class Exam13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1, num2;
		for(num1=1; num1<=9; num1++){
			for(num2=1; num2<=9; num2++){
				System.out.print(num1+"*"+num2+"="+num1*num2+" ");
				System.out.print("\t");
			}
			System.out.println();
		}
	}

}
