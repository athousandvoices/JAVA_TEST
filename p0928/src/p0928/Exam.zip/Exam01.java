package p0928;

public class Exam01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=7, num2=8, num3=10;
		int sum = num1+num2+num3;
		double average = (double)sum/3;
		System.out.println("정숫값 x,y,z의 평균을 구합니다.");
		System.out.println("x값:"+num1);
		System.out.println("y값:"+num2);
		System.out.println("z값:"+num3);
		System.out.println("x,y,z의 평균은"+average+"입니다.");
	}
}
