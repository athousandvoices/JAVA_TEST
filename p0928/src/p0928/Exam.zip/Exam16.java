package p0928;

import java.util.Scanner;

public class Exam16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scan = new Scanner(System.in);       
        int s=0;
        int e=0;
        int p=0;
        int sum=0;
        
        System.out.print("시작 값 입력: ");
        s=scan.nextInt();
        System.out.print("끝 값 입력: ");
        e=scan.nextInt();
        System.out.print("증가 값 입력: ");
        p=scan.nextInt();
 
        int i=s;
        while (i<e) {
        	i=i+p;
            sum=sum+i-p;
        }
        System.out.print(s+"에서 "+e+"까지 "+p+"씩  증가한 값의 합: "+sum);
	}

}
